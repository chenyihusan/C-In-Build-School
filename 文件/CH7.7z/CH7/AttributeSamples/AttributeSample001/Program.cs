﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeSample001
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 o = new Class1();
            o.Begin();
            o.Execute();
        }
    }
}
